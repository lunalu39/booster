#install.packages("ape")
library(ape)
#install.packages("phangorn")
library(phangorn)
#install.packages("ips")
library(ips)
#install.packages("phytools")
library(phytools)
#install.packages("phylobase")
library(phylobase)
#install.packages("caper")
library(caper)

#The functions in this package are boased on the “Boosting Felsenstein Phylogenetic Bootstrap” by Lemoine et. al.,
#to compute the compute the Felsen-stein bootstrap values for the evolutionary trees.

#work cited:
#Entfellner, Frederic LemoineJean-Baka Domelevo, et al. “Boosting Felsenstein Phylogenetic Bootstrap.”
#BioRxiv, Cold Spring Harbor Laboratory, 1 Jan. 2017, www.biorxiv.org/content/early/2017/06/23/154542.


#' The transfer distance function.
#'
#' This function is to compute the transfer distance.
#' @param x is the number of estimated gene tree in the estimated gene tree tree list.
#' @param y is the number of bootstrap tree in the 100 bootstrap tree list.
#' @param z is the number of branch of the current estimated gene tree.
#' @param w is the number of branch of the current bootstrap  tree.
#'
#' transfer.dist(x,y,z,w)
transfer.dist<-function(x,y,z,w){
  des1 <- list() #des1 is the descend descendants for the first estimated gene tree
  j<-12
  for(i in 1:estgene[[x]]$Nnode){
    des1[[i]] <- clade.members(j, estgene[[x]], tip.labels=TRUE)
    des1[[i]] <- sort(des1[[i]], decreasing = FALSE)
    j <- j+1
  }

  des2 <- list() #des2 is the descend descendants for one of the bootstrap tree
  k<-12
  for(i in 1:estgene.boot[[x]][[y]]$Nnode){
    des2[[i]] <- clade.members(k, estgene.boot[[x]][[y]], tip.labels=TRUE)
    des2[[i]] <- sort(des2[[i]], decreasing = FALSE)
    k <- k+1
  }

  node <- c(0,1,2,3,4,5,6,7,8,9,10)
  b <- des1[[z]]
  b.res <- node[is.na(pmatch(node,b))]

  b_ <- des2[[w]]
  b_.res <- node[is.na(pmatch(node,b_))]

  #intersection x with y
  inter1 <- intersect(b,b_)
  len1 <- (length(b) - length(inter1))+(length(b_) - length(inter1))

  #intersection x with total\y
  inter2 <- intersect(b,b_.res)
  len2 <- (length(b) - length(inter2))+(length(b_.res) - length(inter2))

  #intersection total\x with y
  inter3 <- intersect(b.res,b_)
  len3 <- (length(b.res) - length(inter3))+(length(b_) - length(inter3))

  #intersection total\x with total\y
  inter4 <- intersect(b.res,b_.res)
  len4 <- (length(b.res) - length(inter4))+(length(b_.res) - length(inter4))

  return(transfer.dist <- min(len1,len2,len3,len4))
}

#' The transfer index function.
#'
#' This function is to compute the transfer index
#' @param x is the number of estimated gene tree in the estimated gene tree tree list.
#' @param y is the number of bootstrap tree in the 100 bootstrap tree list.
#' @param z is the number of branch of the current estimated gene tree.
#'
#' transfer.index(x,y,z)
transfer.index <- function(x,y,z){
  transfer.dist.list <- list()
  for(i in 1:9){
    transfer.dist.list[[i]] <- transfer.dist(x,y,z,i)
  }

  des1 <- list() #des1 is the descend descendants for the first estimated gene tree
  j<-12
  for(i in 1:estgene[[x]]$Nnode){
    des1[[i]] <- clade.members(j, estgene[[x]], tip.labels=TRUE)
    des1[[i]] <- sort(des1[[i]], decreasing = FALSE)
    j <- j+1
  }

  node <- c(0,1,2,3,4,5,6,7,8,9,10)
  b <- des1[[z]]
  b.res <- node[is.na(pmatch(node,b))]

  p <- min(length(b),length(b.res))
  p <- p-1
  transfer.dist.list[[10]] <- p

  return(min(as.numeric(transfer.dist.list)))
}

#' The TBE function.
#'
#' This function is to compute the TBE value
#' @param x is the number of estimated gene trees in the estimated gene tree list.
#' @param y is the number of branch of the current estimated gene tree.
#'
#' TBE(x,y)
TBE <- function(x,y){
  transfer.index.list <- list()
  for(i in 1:100){
    transfer.index.list[[i]] <- transfer.index(x,i,y)
  }
  avg.transfer.index <- do.call(sum,transfer.index.list)/100

  des1 <- list() #des1 is the descend descendants for the first estimated gene tree
  j<-12
  for(i in 1:estgene[[x]]$Nnode){
    des1[[i]] <- clade.members(j, estgene[[x]], tip.labels=TRUE)
    des1[[i]] <- sort(des1[[i]], decreasing = FALSE)
    j <- j+1
  }

  node <- c(0,1,2,3,4,5,6,7,8,9,10)
  b <- des1[[y]]
  b.res <- node[is.na(pmatch(node,b))]

  p <- min(length(b),length(b.res))
  TBE <- 1-(avg.transfer.index/(p-1))

  return(TBE)
}

#######this is the final function, which can directly used to compute the new bootstrap value
#a set of bootstrap value for an estimated gene tree tree;
#x is the number of the estimated gene tree tree;

#' The bootstrap function.
#'
#' This function can directly used to compute the set of new bootstrap values corresponding to the
#' estimated gene tree
#' @param x is the number of the estimated gene tree.
#'
#' bootstrap(x)
bootstrap <- function(x){
  boot <- c()
  for(i in 1:9){
    boot[i] <- TBE(x,i)
  }
  return(boot)
}

